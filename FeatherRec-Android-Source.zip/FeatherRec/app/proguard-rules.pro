# No custom rules needed for the lightweight native app.
